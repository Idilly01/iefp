#exercicio 1: comentarios e print

nome = input("Digite o seu nome: ")
idade = input("Digite a sua idade:")
cidade = input("Qual é a sua cidade de origem")
motivo = input("Diga o motivo pelo que estás a aprender pyton")

print("Me chamo: " + nome)
print("Tenho: " + idade + " de idade")
print("Sou natural de: " + cidade)
print("O motivo pelo qual estou a aprender pyton é: " + motivo)

