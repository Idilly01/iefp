#exercicio 7: joguinho online

iniciarMoedas = 100
completarTarefas = 50
comprarItem = 20

moedas = iniciarMoedas
moedas += completarTarefas
moedas -= comprarItem

print(moedas)