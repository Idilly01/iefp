#calculo de area

altura = int(input("Digite a altura: "))
largura = int(input("Digite a largura: "))

area = altura * largura




print(f"Um retângulo com {largura} m de largura e {altura} m de altura tem uma área de {area}m².")