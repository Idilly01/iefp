#exercicio 3: quebras de linha

nome = input("Digite o seu nome: ")

print(" Olá, " + nome + "! \nBem-vindo à nossa loja online. \nAqui podes encontrar os melhores produtos: \n- Eletrónica \n-Moda \n- Casa \ne Jardim.")













