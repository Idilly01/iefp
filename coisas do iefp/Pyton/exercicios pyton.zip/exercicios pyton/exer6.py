#exercicio 6:


nomeCliente = "Iury Gelber"
arroz = 1.50
feijao = 2.00
leite = 1.00

total = arroz + feijao + leite

print ( f"""
    Ola, {nomeCliente}! 
    suas compras foram: 
    {arroz}
    {feijao}
    {leite}
    O total da sua compra foi de {total}
    Muito obrigada pela preferencia!
    """)
