# corrigindo os erros

meunome = "Carla"   #havia um espaço na variavel
print("Olá " + meunome)
preco = 50       #haviam aspas em valores inteiros
iva = preco * 0.23
print(preco + iva)