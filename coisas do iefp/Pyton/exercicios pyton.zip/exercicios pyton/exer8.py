farinha = 200
acucar = 100
ovos = 2

print( f"""
receita de bolo
-{farinha}g de farinha
-{acucar}g de açúcar
-{ovos} ovos
    """)