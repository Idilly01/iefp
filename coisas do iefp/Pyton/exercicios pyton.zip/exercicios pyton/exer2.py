# lista supermercado

pao = 0.65
leite = 1.00
arroz = 1.50

print("PÃO: " + str(pao))
print("LEITE: " + str(leite))
print("ARROZ: " + str(arroz))

total = pao + leite + arroz

print("O VALOR TOTAL É: " + str(total))